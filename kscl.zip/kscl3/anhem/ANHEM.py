def timUoc(n):
    uoc=[]
    for i in range(2, int(n**.5)+2):
        if n%i==0:
            uoc.append(i)
            if n//i in uoc == False:
                uoc.append(n//i)
    return uoc

fi=open("ANHEM.INP")
fo=open("ANHEM.OUT", "w")
m,n=list(map(int, fi.readline().strip().split()))
fi.close()
tm=sum(timUoc(m))
tn=sum(timUoc(n))
if tm==tn:
    fo.write("YES")
else:
    fo.write("NO")
fo.close()